# Craftsman en GitHub (compila el APK solo, sin PC)

## 1. Crea el repo
En github.com (modo escritorio del navegador): New repository > nombre `craftsman` > Create (vacío, sin README).

## 2. Crea un token (una sola vez)
GitHub > Settings > Developer settings > Personal access tokens > Tokens (classic) > Generate new token.
Marca los permisos **repo** y **workflow**. Copia el token.

## 3. Sube el proyecto desde Termux
```
termux-setup-storage
pkg install -y git unzip
mkdir craftsman && cd craftsman
unzip ~/storage/downloads/Craftsman-GitHub.zip
bash subir.sh https://github.com/TU_USUARIO/craftsman.git
```
Usuario = tu usuario de GitHub. Contraseña = pega el token.

## 4. Baja el APK
En tu repo abre la pestaña **Actions**: corre "Build APK" (tarda unos 6 minutos).
Cuando termine, el APK está en **Releases > Craftsman (última versión) > Craftsman-debug.apk**
(también en el run de Actions, abajo, en "Artifacts").

## Si el build falla
Abre el run en Actions, toca el paso rojo "Compilar APK (debug)", copia las líneas que empiezan con `e:` y mándaselas a Claude.
