#!/data/data/com.termux/files/usr/bin/bash
# Sube este proyecto a tu repo de GitHub desde Termux.
# Uso:  bash subir.sh https://github.com/TU_USUARIO/TU_REPO.git
set -e
if [ -z "$1" ]; then echo "Falta la URL del repo. Ejemplo: bash subir.sh https://github.com/usuario/craftsman.git"; exit 1; fi
command -v git >/dev/null 2>&1 || pkg install -y git
git config user.name  >/dev/null 2>&1 || git config --global user.name  "Craftsman"
git config user.email >/dev/null 2>&1 || git config --global user.email "craftsman@example.com"
[ -d .git ] || git init -q
git branch -M main
git add -A
git commit -q -m "Craftsman Kotlin" || true
git remote remove origin 2>/dev/null || true
git remote add origin "$1"
echo "Cuando pida usuario: tu usuario de GitHub. Cuando pida contraseña: pega tu TOKEN (no tu contraseña)."
git push -u origin main
echo "Listo. Entra a tu repo > pestaña Actions y espera ~6 min. El APK aparece en Releases."
