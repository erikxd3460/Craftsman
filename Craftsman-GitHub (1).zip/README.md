# Craftsman (Craftam 3D en Kotlin)
Proyecto Android (Kotlin + OpenGL ES 2.0, sin librerías externas). Todo el contenido sale de `app/src/main/assets/`:

| Carpeta | Qué controla |
|---|---|
| `Craftam GH/` | bloques, ítems, texturas, sonidos, modelos, animaciones, recetas, mobs, partículas |
| `world/world.json` | semilla/físicas (gravedad, salto, velocidad), nivel del mar, biomas, minerales |
| `world/structures/` | casas, pozo del desierto, mina, ruinas, calabazas |
| `menu/MenGd.json` | pantallas del menú (Jugar / Opciones / Salir), opciones por defecto, título, música y clic |
| `Tactil-controles/tactil.json` | posición y tamaño del joystick, botones y hotbar |

El mundo y tu posición se guardan al pausar/salir (`Guardar y salir al menú`) y se cargan con **Jugar > Cargar mundo**.

## Compilar el APK
1. Abre la carpeta con Android Studio (Hedgehog o más nuevo).
2. Espera el Sync de Gradle.
3. Build > Build APK(s) -> `app/build/outputs/apk/debug/`.
