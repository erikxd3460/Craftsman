plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.craftam.game"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.craftam.game"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.2"
    }
    androidResources { noCompress += listOf("wav", "png", "json") }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildTypes { release { isMinifyEnabled = false } }
}
