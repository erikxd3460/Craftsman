package com.craftam.game

import android.app.Activity
import android.content.Context
import android.graphics.*
import android.os.Vibrator
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/** Capa 2D: menú (menu/MenGd.json), controles (Tactil-controles/tactil.json), hotbar, vida e inventario. */
class HudView(ctx: Context, val g: Game, val pk: Pack) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val paint = Paint().apply { isAntiAlias = true; textSize = 14 * d; typeface = Typeface.MONOSPACE; isFilterBitmap = false }
    private val bgPaint = Paint().apply { isFilterBitmap = false; colorFilter = PorterDuffColorFilter(Color.rgb(90, 90, 90), PorterDuff.Mode.MULTIPLY) }
    private val btnPaint = Paint().apply { isFilterBitmap = false }
    private class Btn(val id: String, val cx: Float, val cy: Float, val r: Float, val label: String, val toggle: Boolean)
    private class Ptr(var role: String, var x: Float, var y: Float, val sx: Float, val sy: Float, val t0: Long)
    private class Act(val r: RectF, val f: () -> Unit)
    private class Slider(val label: String, val min: Float, val max: Float, val step: Float, val get: () -> Float, val set: (Float) -> Unit, val fmt: (Float) -> String) { val r = RectF() }
    private val sliders = ArrayList<Slider>()
    private val shade = Paint(); private var shadeH = 0
    private val btns = ArrayList<Btn>(); private val hits = ArrayList<Act>(); private val ptrs = HashMap<Int, Ptr>()
    private var jcx = 0f; private var jcy = 0f; private var jr = 60f; private var knobX = 0f; private var knobY = 0f
    private var lastJoy = 0L; private var swipeAcc = 0f
    private var hbTop = 0f; private var hbOn = true
    @Suppress("DEPRECATION") private val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    var screen = "menu"; private var from = "menu"
    private var scroll = 0f; private val invList = ArrayList<String>()
    private val click get() = pk.menu.optString("click", "click_ui")

    init {
        pk.blocks.forEach { b -> if (b != null && b.name != "water" && b.name != "lava" && b.name != "bedrock") invList.add("b:" + b.name) }
        pk.items.keys.forEach { invList.add("i:$it") }
        g.sfx.sfxVol = g.st.sounds; g.sfx.musicVol = g.st.music
        g.onBreak = { if (pk.tactil.optBoolean("vibrate_on_break", false)) try { vib?.vibrate(18) } catch (e: Exception) { } }
        g.sfx.menuMusic(true)
        val st = g.st
        for (l in menuList("options")) when (l) {
            "Sensibilidad" -> sliders.add(Slider(l, .1f, 1f, .1f, { st.sens }, { st.sens = it }, { String.format("%.1f", it) }))
            "Distancia de render" -> sliders.add(Slider(l, 2f, 8f, 1f, { st.rd.toFloat() }, { st.rd = it.roundToInt() }, { "${it.roundToInt()} chunks" }))
            "Volumen música" -> sliders.add(Slider(l, 0f, 1f, .05f, { st.music }, { st.music = it }, { "${(it * 100).roundToInt()}%" }))
            "Volumen sonidos" -> sliders.add(Slider(l, 0f, 1f, .05f, { st.sounds }, { st.sounds = it }, { "${(it * 100).roundToInt()}%" }))
            "Tamaño de botones" -> sliders.add(Slider(l, .6f, 1.6f, .1f, { st.btn }, { st.btn = it }, { String.format("%.1fx", it) }))
            "FOV" -> sliders.add(Slider(l, 50f, 100f, 5f, { st.fov.toFloat() }, { st.fov = it.roundToInt() }, { "${it.roundToInt()}°" }))
        }
    }

    private fun applyOptions() { g.st.save(); g.sfx.sfxVol = g.st.sounds; g.sfx.musicVol = g.st.music; g.sfx.applyVol(); layout() }
    private fun setSlider(s: Slider, x: Float) {
        val t = ((x - s.r.left) / s.r.width()).coerceIn(0f, 1f)
        val v = s.min + t * (s.max - s.min)
        s.set((((v - s.min) / s.step).roundToInt() * s.step + s.min).coerceIn(s.min, s.max)); applyOptions()
    }
    private fun hitSlider(s: Slider, x: Float, y: Float) = RectF(s.r.left - 10 * d, s.r.top - 16 * d, s.r.right + 10 * d, s.r.bottom + 16 * d).contains(x, y)

    // ---------- diseño táctil (desde tactil.json)
    private fun layout() {
        btns.clear(); if (width == 0) return
        val sc = g.st.btn; val j = pk.tactil.getJSONObject("joystick")
        jcx = width * j.getDouble("x").toFloat(); jcy = height * j.getDouble("y").toFloat(); jr = width * j.getDouble("r").toFloat() * sc
        val arr = pk.tactil.getJSONArray("buttons")
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i); val id = b.getString("id")
            val lab = when (id) { "jump" -> "▲"; "sneak" -> "▼"; "break_place" -> "⛏"; "inventory" -> "🎒"; "pause" -> "II"; "fly" -> "✈"; "drop" -> "⬇"; "sprint" -> "»"; else -> "?" }
            btns.add(Btn(id, width * b.getDouble("x").toFloat(), height * b.getDouble("y").toFloat(), width * b.getDouble("r").toFloat() * sc, lab, b.optBoolean("toggle", false)))
        }
        val hb = pk.tactil.optJSONObject("hotbar"); hbOn = true
        hbTop = min(height * (hb?.optDouble("y", .95) ?: .95).toFloat() - slot() / 2, height - slot() - 4 * d)
    }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { layout() }
    private fun slot() = min(48 * d, width / 11f)
    private fun hbX() = (width - 9 * slot()) / 2
    private fun tileRect(t: Int) = Rect((t and 15) * 16, (t shr 4) * 16, (t and 15) * 16 + 16, (t shr 4) * 16 + 16)
    private fun tileOf(s: String): Int { if (s.isEmpty()) return -1; val n = s.substring(2); return if (s[0] == 'b') pk.blocks[pk.bid[n] ?: 1]!!.side else (pk.items[n]?.tile ?: 0) }

    // ---------- flujo
    private fun resetInput() { g.joyX = 0f; g.joyY = 0f; g.brkIn = false; g.jumpIn = false; g.downIn = false; knobX = 0f; knobY = 0f; ptrs.clear() }
    private fun startGame(k: Int) { g.startReq = k; screen = "game"; resetInput(); g.sfx.menuMusic(false) }
    private fun openPause() { resetInput(); g.running = false; screen = "pause" }
    private fun resume() { screen = "game"; g.running = true }
    fun back() {
        when (screen) {
            "game" -> openPause(); "pause", "inv" -> resume(); "options" -> screen = from; "play" -> screen = "menu"
            else -> (context as? Activity)?.finish()
        }
    }

    // ---------- dibujo
    override fun onDraw(c: Canvas) {
        postInvalidateOnAnimation(); hits.clear()
        when (screen) {
            "menu", "play", "options" -> drawMenu(c)
            "inv" -> drawInv(c)
            "pause" -> { drawGame(c); drawPause(c) }
            else -> drawGame(c)
        }
    }
    private fun bigText(c: Canvas, t: String, cx: Float, cy: Float, size: Float) {
        paint.textAlign = Paint.Align.CENTER; paint.textSize = size; paint.isFakeBoldText = true
        paint.color = Color.argb(160, 0, 0, 0); c.drawText(t, cx + 3 * d, cy + 3 * d, paint)
        paint.color = Color.WHITE; c.drawText(t, cx, cy, paint); paint.isFakeBoldText = false; paint.textSize = 14 * d; paint.textAlign = Paint.Align.LEFT
    }
    private fun button(c: Canvas, label: String, cx: Float, cy: Float, w: Float, h: Float, on: Boolean = true, act: () -> Unit) {
        val r = RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2); val e = max(2f, 2.2f * d)
        c.drawBitmap(pk.btnTex, null, r, btnPaint)
        if (!on) { paint.color = Color.argb(120, 0, 0, 0); c.drawRect(r, paint) }
        paint.color = Color.argb(95, 255, 255, 255); c.drawRect(r.left, r.top, r.right, r.top + e, paint); c.drawRect(r.left, r.top, r.left + e, r.bottom, paint)
        paint.color = Color.argb(120, 0, 0, 0); c.drawRect(r.left, r.bottom - e, r.right, r.bottom, paint); c.drawRect(r.right - e, r.top, r.right, r.bottom, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2 * d; paint.color = Color.rgb(20, 20, 25); c.drawRect(r, paint); paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER; paint.textSize = min(18 * d, h * .42f); paint.isFakeBoldText = true
        val ty = cy + paint.textSize * .33f
        paint.color = Color.argb(180, 40, 40, 40); c.drawText(label, cx + 1.5f * d, ty + 1.5f * d, paint)
        paint.color = if (on) Color.WHITE else Color.rgb(150, 150, 150); c.drawText(label, cx, ty, paint)
        paint.isFakeBoldText = false; paint.textAlign = Paint.Align.LEFT; paint.textSize = 14 * d
        if (on) hits.add(Act(r) { g.sfx.play(click); act() })
    }
    private fun drawBg(c: Canvas) {
        val t = 64 * d; var y = 0f
        while (y < height) { var x = 0f; while (x < width) { c.drawBitmap(pk.bgTex, null, RectF(x, y, x + t, y + t), bgPaint); x += t }; y += t }
        if (shadeH != height) { shade.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), Color.argb(170, 0, 0, 0), Color.argb(60, 0, 0, 0), Shader.TileMode.CLAMP); shadeH = height }
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), shade)
    }
    private fun menuList(name: String): List<String> { val a = pk.menu.getJSONObject("screens").getJSONArray(name); return List(a.length()) { a.getString(it) } }

    private fun drawMenu(c: Canvas) {
        drawBg(c)
        val tt = System.nanoTime() / 1e9f
        val lw = min(width * .62f, 440 * d); val lh = lw / 4f
        val ly = height * .03f + sin(tt * 1.6f) * 3 * d
        if (screen == "options") { bigText(c, "OPCIONES", width / 2f, height * .15f, height * .085f); drawOptions(c); return }
        c.drawBitmap(pk.logo, null, RectF(width / 2 - lw / 2, ly, width / 2 + lw / 2, ly + lh), btnPaint)
        // frase amarilla que late, como en Minecraft
        c.save(); c.rotate(-14f, width / 2 + lw * .40f, ly + lh * .95f)
        paint.textAlign = Paint.Align.CENTER; paint.isFakeBoldText = true; paint.textSize = lh * .2f * (1f + .06f * sin(tt * 4f))
        paint.color = Color.argb(200, 60, 50, 0); c.drawText("¡En 3D!", width / 2 + lw * .40f + 2 * d, ly + lh * .95f + 2 * d, paint)
        paint.color = Color.rgb(255, 235, 60); c.drawText("¡En 3D!", width / 2 + lw * .40f, ly + lh * .95f, paint)
        paint.isFakeBoldText = false; paint.textAlign = Paint.Align.LEFT; paint.textSize = 14 * d; c.restore()
        val bw = min(width * .5f, 300 * d); val bh = min(50 * d, height * .13f); val gap = bh * 1.25f; val y0 = height * .03f + lh + bh * .95f
        when (screen) {
            "menu" -> menuList("main").forEachIndexed { i, s ->
                button(c, s, width / 2f, y0 + i * gap, bw, bh) {
                    when (s) { "Jugar" -> screen = "play"; "Opciones" -> { from = "menu"; screen = "options" }; else -> (context as? Activity)?.finish() }
                }
            }
            else -> {
                val l = menuList("play")
                l.forEachIndexed { i, s ->
                    button(c, s, width / 2f, y0 + i * gap, bw, bh, s != "Cargar mundo" || g.hasSave()) { if (s == "Mundo nuevo") startGame(1) else startGame(2) }
                }
                button(c, "Atrás", width / 2f, y0 + l.size * gap, bw, bh) { screen = "menu" }
                if (!g.hasSave()) { paint.color = Color.LTGRAY; paint.textSize = 11 * d; paint.textAlign = Paint.Align.CENTER; c.drawText("(aún no hay mundo guardado)", width / 2f, y0 + (l.size + 1) * gap - bh * .2f, paint); paint.textAlign = Paint.Align.LEFT; paint.textSize = 14 * d }
            }
        }
    }

    private fun drawOptions(c: Canvas) {
        val top = height * .22f; val bot = height * .78f; val rowH = (bot - top) / 3; val cw = width * .38f
        // panel
        paint.color = Color.argb(120, 0, 0, 0); c.drawRect(width * .04f, top - rowH * .1f, width * .96f, bot + rowH * .05f, paint)
        sliders.forEachIndexed { i, s ->
            val col = i / 3; val row = i % 3
            val x0 = width * (.27f + .46f * col) - cw / 2; val y0 = top + row * rowH
            val th = max(10 * d, rowH * .16f); val ty = y0 + rowH * .5f
            s.r.set(x0, ty, x0 + cw, ty + th)
            val v = s.get(); val t = ((v - s.min) / (s.max - s.min)).coerceIn(0f, 1f)
            paint.textSize = min(14 * d, rowH * .22f); paint.color = Color.WHITE; paint.isFakeBoldText = true
            c.drawText(s.label, x0, y0 + rowH * .38f, paint)
            paint.textAlign = Paint.Align.RIGHT; paint.color = Color.rgb(255, 235, 60); c.drawText(s.fmt(v), x0 + cw, y0 + rowH * .38f, paint)
            paint.textAlign = Paint.Align.LEFT; paint.isFakeBoldText = false
            // pista
            paint.color = Color.rgb(25, 25, 30); c.drawRect(s.r.left - 2 * d, s.r.top - 2 * d, s.r.right + 2 * d, s.r.bottom + 2 * d, paint)
            paint.color = Color.rgb(70, 70, 75); c.drawRect(s.r, paint)
            paint.color = Color.rgb(84, 158, 48); c.drawRect(s.r.left, s.r.top, s.r.left + s.r.width() * t, s.r.bottom, paint)
            paint.color = Color.argb(70, 255, 255, 255); c.drawRect(s.r.left, s.r.top, s.r.left + s.r.width() * t, s.r.top + th * .3f, paint)
            // perilla
            val kx = s.r.left + s.r.width() * t; val kw = 8 * d
            paint.color = Color.rgb(25, 25, 30); c.drawRect(kx - kw / 2 - 2 * d, s.r.top - 6 * d, kx + kw / 2 + 2 * d, s.r.bottom + 6 * d, paint)
            paint.color = Color.rgb(200, 200, 205); c.drawRect(kx - kw / 2, s.r.top - 4 * d, kx + kw / 2, s.r.bottom + 4 * d, paint)
            paint.color = Color.argb(120, 255, 255, 255); c.drawRect(kx - kw / 2, s.r.top - 4 * d, kx + kw / 2, s.r.top - 1 * d, paint)
        }
        paint.textSize = 14 * d
        val bh = min(46 * d, height * .12f); val by = height * .88f; val bw = min(width * .32f, 230 * d)
        button(c, "Restablecer", width / 2f - bw * .57f, by, bw, bh) { g.st.reset(); applyOptions() }
        button(c, "Volver", width / 2f + bw * .57f, by, bw, bh) { screen = from }
    }

    private fun drawPause(c: Canvas) {
        paint.color = Color.argb(160, 0, 0, 0); c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        val bw = min(width * .55f, 340 * d); val bh = min(50 * d, height * .14f); val gap = bh * 1.25f; val y0 = height * .3f
        bigText(c, "PAUSA", width / 2f, y0 - bh, bh * .8f)
        button(c, "Continuar", width / 2f, y0, bw, bh) { resume() }
        button(c, "Opciones", width / 2f, y0 + gap, bw, bh) { from = "pause"; screen = "options" }
        button(c, "Guardar y salir al menú", width / 2f, y0 + 2 * gap, bw, bh) { g.exitReq = true; screen = "menu"; g.sfx.menuMusic(true) }
    }

    private fun drawGame(c: Canvas) {
        if (!g.ready) { paint.color = Color.WHITE; paint.textAlign = Paint.Align.CENTER; c.drawText("Generando mundo...", width / 2f, height / 2f, paint); paint.textAlign = Paint.Align.LEFT; return }
        if (g.hurtT > 0) { paint.color = Color.argb((g.hurtT * 255).toInt().coerceIn(0, 255), 255, 0, 0); c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint) }
        paint.color = Color.WHITE
        c.drawRect(width / 2f - 9 * d, height / 2f - d, width / 2f + 9 * d, height / 2f + d, paint)
        c.drawRect(width / 2f - d, height / 2f - 9 * d, width / 2f + d, height / 2f + 9 * d, paint)
        // joystick
        paint.style = Paint.Style.FILL; paint.color = Color.argb(60, 255, 255, 255); c.drawCircle(jcx, jcy, jr, paint)
        paint.color = Color.argb(120, 255, 255, 255); c.drawCircle(jcx + knobX * jr * .6f, jcy + knobY * jr * .6f, jr * .4f, paint)
        paint.textAlign = Paint.Align.CENTER
        for (b in btns) {
            val on = (b.id == "sneak" && g.sneak) || (b.id == "sprint" && g.sprint) || (b.id == "fly" && g.fly)
            paint.color = Color.argb(if (on) 130 else 70, 255, 255, 255); c.drawCircle(b.cx, b.cy, b.r, paint)
            paint.color = Color.WHITE; c.drawText(b.label, b.cx, b.cy + 6 * d, paint)
        }
        paint.textAlign = Paint.Align.LEFT
        val s = slot()
        for (i in 0 until 9) {
            val x = hbX() + i * s; val y = hbTop
            paint.color = Color.argb(140, 0, 0, 0); c.drawRect(x, y, x + s - 2, y + s - 2, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = if (i == g.sel) 3 * d else d; paint.color = if (i == g.sel) Color.WHITE else Color.GRAY
            c.drawRect(x, y, x + s - 2, y + s - 2, paint); paint.style = Paint.Style.FILL
            val t = tileOf(g.hot[i]); if (t >= 0) c.drawBitmap(pk.atlas, tileRect(t), RectF(x + 4 * d, y + 4 * d, x + s - 6 * d, y + s - 6 * d), btnPaint)
        }
        val hs = min(16 * d, width / 24f)
        for (i in 0 until 10) {
            val x = hbX() + i * (hs + d); val y = hbTop - hs - 4 * d; val v = g.hp - i * 2
            paint.color = Color.rgb(50, 0, 0); c.drawRect(x, y, x + hs, y + hs, paint)
            paint.color = if (v >= 2) Color.rgb(230, 30, 30) else if (v >= 1) Color.rgb(160, 30, 30) else Color.rgb(50, 0, 0)
            c.drawRect(x + 2 * d, y + 2 * d, x + hs - 2 * d, y + hs - 2 * d, paint)
        }
        paint.color = Color.WHITE; paint.textSize = 12 * d
        if (g.hot[g.sel].isNotEmpty()) c.drawText(g.hot[g.sel].substring(2).replace('_', ' '), hbX(), hbTop - hs - 10 * d, paint)
        paint.textSize = 14 * d
        val b = g.brk
        if (b != null && b.need > 0) {
            paint.color = Color.argb(140, 0, 0, 0); c.drawRect(width / 2f - 40 * d, height / 2f + 22 * d, width / 2f + 40 * d, height / 2f + 28 * d, paint)
            paint.color = Color.rgb(255, 200, 50); c.drawRect(width / 2f - 40 * d, height / 2f + 22 * d, width / 2f - 40 * d + 80 * d * (b.t / b.need).coerceIn(0f, 1f), height / 2f + 28 * d, paint)
        }
        paint.color = Color.WHITE; c.drawText("Craftsman" + (if (g.fly) "  ✈" else ""), 8 * d, 18 * d, paint)
    }

    private fun cell() = 44 * d
    private fun drawInv(c: Canvas) {
        paint.color = Color.argb(235, 0, 0, 0); c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        val cs = cell(); val cols = max(1, (width / cs).toInt()); val ox = (width - cols * cs) / 2
        for ((i, s) in invList.withIndex()) {
            val x = ox + (i % cols) * cs; val y = 50 * d + (i / cols) * cs - scroll
            if (y < 30 * d || y > height) continue
            paint.color = Color.argb(150, 90, 90, 90); c.drawRect(x + 2, y + 2, x + cs - 2, y + cs - 2, paint)
            c.drawBitmap(pk.atlas, tileRect(tileOf(s)), RectF(x + 6 * d, y + 6 * d, x + cs - 6 * d, y + cs - 6 * d), btnPaint)
        }
        paint.color = Color.rgb(40, 40, 40); c.drawRect(0f, 0f, width.toFloat(), 44 * d, paint)
        paint.color = Color.WHITE; paint.textSize = 12 * d; c.drawText("Toca un objeto para ponerlo en la ranura elegida. Arrastra para bajar.", 10 * d, 28 * d, paint); paint.textSize = 14 * d
        paint.color = Color.rgb(170, 40, 40); c.drawRect(width - 70 * d, 4 * d, width - 6 * d, 40 * d, paint)
        paint.color = Color.WHITE; c.drawText("CERRAR", width - 66 * d, 28 * d, paint)
    }

    // ---------- táctil
    private fun hitBtn(x: Float, y: Float): Btn? = btns.firstOrNull { hypot(x - it.cx, y - it.cy) <= it.r * 1.15f }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val a = e.actionMasked; val idx = e.actionIndex
        when (a) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> down(e.getPointerId(idx), e.getX(idx), e.getY(idx))
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(idx), e.getX(idx), e.getY(idx))
            MotionEvent.ACTION_CANCEL -> for (id in ptrs.keys.toList()) up(id, ptrs[id]!!.x, ptrs[id]!!.y)
        }
        return true
    }
    private fun down(id: Int, x: Float, y: Float) {
        val now = System.currentTimeMillis()
        if (screen == "inv") {
            if (x > width - 70 * d && y < 44 * d) { resume(); return }
            ptrs[id] = Ptr("inv", x, y, x, y, now); return
        }
        if (screen == "options") {
            val i = sliders.indexOfFirst { hitSlider(it, x, y) }
            if (i >= 0) { setSlider(sliders[i], x); ptrs[id] = Ptr("sl$i", x, y, x, y, now); return }
        }
        if (screen != "game") { ptrs[id] = Ptr("ui", x, y, x, y, now); return }
        val b = hitBtn(x, y)
        if (b != null) {
            ptrs[id] = Ptr("b:" + b.id, x, y, x, y, now)
            when (b.id) {
                "jump" -> g.jumpIn = true
                "sneak" -> g.sneak = !g.sneak
                "break_place" -> g.brkIn = true
                "inventory" -> { resetInput(); g.running = false; screen = "inv" }
                "pause" -> openPause()
                "fly" -> g.flyEv = true
                "drop" -> { g.hot[g.sel] = ""; g.sfx.play(click) }
                "sprint" -> g.sprint = !g.sprint
            }
            return
        }
        if (y > hbTop && x > hbX() && x < hbX() + 9 * slot()) { g.sel = ((x - hbX()) / slot()).toInt().coerceIn(0, 8); g.sfx.play(click); swipeAcc = 0f; ptrs[id] = Ptr("hb", x, y, x, y, now); return }
        if (hypot(x - jcx, y - jcy) < jr * 1.4f) {
            if (now - lastJoy < 300) g.sprint = !g.sprint
            lastJoy = now; ptrs[id] = Ptr("joy", x, y, x, y, now); move(id, x, y); return
        }
        ptrs[id] = Ptr("look", x, y, x, y, now)
    }
    private fun move(id: Int, x: Float, y: Float) {
        val p = ptrs[id] ?: return
        when (p.role) {
            "look" -> { g.lookDX += x - p.x; g.lookDY += y - p.y }
            "joy" -> { var a = (x - jcx) / jr; var b = (y - jcy) / jr; val l = hypot(a, b); if (l > 1) { a /= l; b /= l }; knobX = a; knobY = b; g.joyX = a; g.joyY = b }
            "hb" -> { swipeAcc += x - p.x; val s = slot(); while (swipeAcc > s) { g.sel = min(8, g.sel + 1); swipeAcc -= s }; while (swipeAcc < -s) { g.sel = max(0, g.sel - 1); swipeAcc += s } }
            "inv" -> scroll = (scroll - (y - p.y)).coerceIn(0f, max(0f, ((invList.size / max(1, (width / cell()).toInt()) + 1) * cell() - height + 60 * d)))
            else -> if (p.role.startsWith("sl")) setSlider(sliders[p.role.substring(2).toInt()], x)
        }
        p.x = x; p.y = y
    }
    private fun up(id: Int, x: Float, y: Float) {
        val p = ptrs.remove(id) ?: return
        val tap = hypot(x - p.sx, y - p.sy) < 12 * d
        when {
            p.role == "joy" -> { knobX = 0f; knobY = 0f; g.joyX = 0f; g.joyY = 0f }
            p.role == "ui" -> if (tap) hits.firstOrNull { it.r.contains(x, y) }?.f?.invoke()
            p.role == "b:jump" -> g.jumpIn = false
            p.role == "b:break_place" -> { g.brkIn = false; if (System.currentTimeMillis() - p.t0 < 220) g.plcEv = true }
            p.role == "inv" && tap -> {
                val cs = cell(); val cols = max(1, (width / cs).toInt()); val ox = (width - cols * cs) / 2
                val col = ((x - ox) / cs).toInt(); val row = ((y - 50 * d + scroll) / cs).toInt(); val i = row * cols + col
                if (col in 0 until cols && row >= 0 && i in 0 until invList.size) { g.hot[g.sel] = invList[i]; g.sfx.play(click) }
            }
        }
    }
}
