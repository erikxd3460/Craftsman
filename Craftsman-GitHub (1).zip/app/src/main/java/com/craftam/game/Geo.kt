package com.craftam.game

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/** Lista de vértices: x y z u v sombra (6 floats). */
class FB(cap: Int = 1 shl 14) {
    var a = FloatArray(cap); var n = 0
    fun v(x: Float, y: Float, z: Float, u: Float, w: Float, s: Float) {
        if (n + 6 > a.size) a = a.copyOf(a.size * 2)
        a[n++] = x; a[n++] = y; a[n++] = z; a[n++] = u; a[n++] = w; a[n++] = s
    }
    fun buf(): FloatBuffer {
        val b = ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        b.put(a, 0, n); b.position(0); return b
    }
}

object Geo {
    val FD = arrayOf(intArrayOf(0, 1, 0), intArrayOf(0, -1, 0), intArrayOf(1, 0, 0), intArrayOf(-1, 0, 0), intArrayOf(0, 0, 1), intArrayOf(0, 0, -1))
    val FC = arrayOf(
        arrayOf(intArrayOf(0, 1, 1), intArrayOf(1, 1, 1), intArrayOf(1, 1, 0), intArrayOf(0, 1, 0)),
        arrayOf(intArrayOf(0, 0, 0), intArrayOf(1, 0, 0), intArrayOf(1, 0, 1), intArrayOf(0, 0, 1)),
        arrayOf(intArrayOf(1, 0, 1), intArrayOf(1, 0, 0), intArrayOf(1, 1, 0), intArrayOf(1, 1, 1)),
        arrayOf(intArrayOf(0, 0, 0), intArrayOf(0, 0, 1), intArrayOf(0, 1, 1), intArrayOf(0, 1, 0)),
        arrayOf(intArrayOf(0, 0, 1), intArrayOf(1, 0, 1), intArrayOf(1, 1, 1), intArrayOf(0, 1, 1)),
        arrayOf(intArrayOf(1, 0, 0), intArrayOf(0, 0, 0), intArrayOf(0, 1, 0), intArrayOf(1, 1, 0)))
    val FS = floatArrayOf(1f, .5f, .8f, .8f, .65f, .65f)
    val UVT = arrayOf(floatArrayOf(0f, 0f), floatArrayOf(1f, 0f), floatArrayOf(1f, 1f), floatArrayOf(0f, 1f))
    val UVS = arrayOf(floatArrayOf(0f, 1f), floatArrayOf(1f, 1f), floatArrayOf(1f, 0f), floatArrayOf(0f, 0f))
    val IDX = intArrayOf(0, 1, 2, 0, 2, 3)

    fun quad(o: FB, p: Array<FloatArray>, t: Int, top: Boolean, s: Float) {
        val uv = if (top) UVT else UVS; val e = .002f
        for (i in IDX) {
            val u = ((t and 15) + e + uv[i][0] * (1 - 2 * e)) / 16f
            val v = ((t shr 4) + e + uv[i][1] * (1 - 2 * e)) / 16f
            o.v(p[i][0], p[i][1], p[i][2], u, v, s)
        }
    }

    /** Caja centrada en (cx,cy,cz). xf transforma cada esquina (para animar). sd>0 fuerza sombra. */
    fun box(o: FB, cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float, tT: Int, tB: Int, tS: Int,
            xf: ((FloatArray) -> FloatArray)?, sd: Float) {
        for (f in 0 until 6) {
            val c = FC[f]
            val p = Array(4) { i ->
                val q = floatArrayOf(cx + (c[i][0] - .5f) * sx, cy + (c[i][1] - .5f) * sy, cz + (c[i][2] - .5f) * sz)
                if (xf != null) xf(q) else q
            }
            quad(o, p, if (f == 0) tT else if (f == 1) tB else tS, f < 2, if (sd > 0f) sd else FS[f])
        }
    }
}
