package com.craftam.game

import android.opengl.GLES20 as GL
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

class GameRenderer(val g: Game, val pk: Pack) : GLSurfaceView.Renderer {
    private var prog = 0; private var tex = 0
    private var uM = 0; private var uT = 0; private var uL = 0; private var uA = 0; private var uF = 0; private var uFc = 0
    private var dynB = 0; private var lineB = 0
    private var aspect = 1f; private var last = 0L
    private val DEG = (PI / 180).toFloat()
    private val pm = FloatArray(16); private val vm = FloatArray(16); private val mm = FloatArray(16)

    private fun sh(t: Int, s: String): Int { val o = GL.glCreateShader(t); GL.glShaderSource(o, s); GL.glCompileShader(o); return o }
    private fun genBuf(): Int { val a = IntArray(1); GL.glGenBuffers(1, a, 0); return a[0] }

    override fun onSurfaceCreated(u: GL10?, c: EGLConfig?) {
        prog = GL.glCreateProgram()
        GL.glAttachShader(prog, sh(GL.GL_VERTEX_SHADER, "attribute vec3 p;attribute vec2 u;attribute float s;uniform mat4 m;varying vec2 vu;varying float vs,vd;void main(){gl_Position=m*vec4(p,1.);vu=u;vs=s;vd=gl_Position.w;}"))
        GL.glAttachShader(prog, sh(GL.GL_FRAGMENT_SHADER, "precision mediump float;uniform sampler2D t;uniform float L,A,F;uniform vec3 fc;varying vec2 vu;varying float vs,vd;void main(){vec4 c=texture2D(t,vu);if(A>.5){if(c.a<.5)discard;c.a=1.;}float l=vs>1.5?vs-2.:vs*L;vec3 o=c.rgb*l;o=mix(o,fc,clamp((vd-F*.6)/(F*.4),0.,1.));gl_FragColor=vec4(o,c.a);}"))
        GL.glBindAttribLocation(prog, 0, "p"); GL.glBindAttribLocation(prog, 1, "u"); GL.glBindAttribLocation(prog, 2, "s")
        GL.glLinkProgram(prog); GL.glUseProgram(prog)
        uM = GL.glGetUniformLocation(prog, "m"); uT = GL.glGetUniformLocation(prog, "t"); uL = GL.glGetUniformLocation(prog, "L")
        uA = GL.glGetUniformLocation(prog, "A"); uF = GL.glGetUniformLocation(prog, "F"); uFc = GL.glGetUniformLocation(prog, "fc")
        for (i in 0..2) GL.glEnableVertexAttribArray(i)
        val t = IntArray(1); GL.glGenTextures(1, t, 0); tex = t[0]
        GL.glBindTexture(GL.GL_TEXTURE_2D, tex)
        GLUtils.texImage2D(GL.GL_TEXTURE_2D, 0, pk.atlas, 0)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_NEAREST); GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_NEAREST)
        GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_S, GL.GL_CLAMP_TO_EDGE); GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_WRAP_T, GL.GL_CLAMP_TO_EDGE)
        GL.glEnable(GL.GL_DEPTH_TEST); GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA)
        dynB = genBuf(); lineB = genBuf()
        last = System.nanoTime()
    }

    override fun onSurfaceChanged(u: GL10?, w: Int, h: Int) { GL.glViewport(0, 0, w, h); aspect = w.toFloat() / h }

    private fun up(buf: Int, fb: FB, usage: Int) {
        GL.glBindBuffer(GL.GL_ARRAY_BUFFER, buf)
        GL.glBufferData(GL.GL_ARRAY_BUFFER, fb.n * 4, if (fb.n > 0) fb.buf() else null, usage)
    }
    private fun attr() {
        GL.glVertexAttribPointer(0, 3, GL.GL_FLOAT, false, 24, 0); GL.glVertexAttribPointer(1, 2, GL.GL_FLOAT, false, 24, 12); GL.glVertexAttribPointer(2, 1, GL.GL_FLOAT, false, 24, 20)
    }
    private fun dyn(fb: FB) { if (fb.n == 0) return; up(dynB, fb, GL.GL_DYNAMIC_DRAW); attr(); GL.glDrawArrays(GL.GL_TRIANGLES, 0, fb.n / 6) }

    override fun onDrawFrame(u: GL10?) {
        val now = System.nanoTime(); val dt = min(.05f, (now - last) / 1e9f); last = now
        if (g.startReq != 0) { val l = g.startReq == 2; g.startReq = 0; g.start(l) }
        if (g.exitReq) {
            g.exitReq = false; g.save()
            for (c in g.world.ch.values) { if (c.bA != 0) GL.glDeleteBuffers(1, intArrayOf(c.bA), 0); if (c.bW != 0) GL.glDeleteBuffers(1, intArrayOf(c.bW), 0) }
            g.world.ch.clear(); g.mobs.clear(); g.ready = false; g.running = false
        }
        if (!g.ready) { GL.glClearColor(.1f, .2f, .1f, 1f); GL.glClear(GL.GL_COLOR_BUFFER_BIT or GL.GL_DEPTH_BUFFER_BIT); return }
        g.update(dt)
        // mallas
        val pcx = floor(g.P.x).toInt() shr 4; val pcz = floor(g.P.z).toInt() shr 4
        var nm = 0
        val list = ArrayList(g.world.ch.values)
        for (c in list) {
            if (abs(c.cx - pcx) > g.RD + 3 || abs(c.cz - pcz) > g.RD + 3) {
                if (c.bA != 0) GL.glDeleteBuffers(1, intArrayOf(c.bA), 0); if (c.bW != 0) GL.glDeleteBuffers(1, intArrayOf(c.bW), 0)
                g.world.remove(c); continue
            }
            if (c.dirty && nm < 2 && abs(c.cx - pcx) <= g.RD && abs(c.cz - pcz) <= g.RD) {
                val (a, w) = g.world.mesh(c)
                if (c.bA == 0) c.bA = genBuf(); if (c.bW == 0) c.bW = genBuf()
                up(c.bA, a, GL.GL_STATIC_DRAW); c.nA = a.n / 6; up(c.bW, w, GL.GL_STATIC_DRAW); c.nW = w.n / 6
                c.dirty = false; nm++
            }
        }
        render(list)
    }

    private fun render(list: List<Chunk>) {
        val P = g.P; val day = g.daylight(); val L = .22f + .78f * day
        var fc = floatArrayOf(.51f * day + .04f, .75f * day + .05f, 1f * day + .12f)
        val eye = floatArrayOf(P.x, P.y + 1.62f, P.z); val cp = cos(g.pitch)
        val inW = g.world.get(floor(eye[0]).toInt(), floor(eye[1]).toInt(), floor(eye[2]).toInt()) == g.water
        if (inW) fc = floatArrayOf(.1f, .25f, .55f)
        val F = if (inW) 18f else g.RD * 16 * .95f
        GL.glClearColor(fc[0], fc[1], fc[2], 1f); GL.glClear(GL.GL_COLOR_BUFFER_BIT or GL.GL_DEPTH_BUFFER_BIT)
        Matrix.perspectiveM(pm, 0, g.st.fov.toFloat(), aspect, .08f, 300f)
        Matrix.setLookAtM(vm, 0, eye[0], eye[1], eye[2], eye[0] - sin(g.yaw) * cp, eye[1] + sin(g.pitch), eye[2] - cos(g.yaw) * cp, 0f, 1f, 0f)
        Matrix.multiplyMM(mm, 0, pm, 0, vm, 0)
        GL.glActiveTexture(GL.GL_TEXTURE0); GL.glBindTexture(GL.GL_TEXTURE_2D, tex); GL.glUniform1i(uT, 0)
        GL.glUniform3f(uFc, fc[0], fc[1], fc[2]); GL.glUniform1f(uL, L)
        // sol y luna
        val ang = (g.dayT - .25f) * 6.2832f; val sx = cos(ang) * 90; val sy = sin(ang) * 90
        val sb = FB(); val ts = pk.tile("c:sun"); val tm = pk.tile("c:moon")
        Geo.box(sb, eye[0] + sx, eye[1] + sy, eye[2] + 20, 12f, 12f, 12f, ts, ts, ts, null, 3f)
        Geo.box(sb, eye[0] - sx, eye[1] - sy, eye[2] - 20, 9f, 9f, 9f, tm, tm, tm, null, 3f)
        GL.glUniformMatrix4fv(uM, 1, false, mm, 0); GL.glUniform1f(uA, 1f); GL.glUniform1f(uF, 1e6f)
        GL.glDisable(GL.GL_DEPTH_TEST); dyn(sb); GL.glEnable(GL.GL_DEPTH_TEST); GL.glClear(GL.GL_DEPTH_BUFFER_BIT)
        GL.glUniform1f(uF, F)
        for (c in list) { if (c.nA == 0) continue; GL.glBindBuffer(GL.GL_ARRAY_BUFFER, c.bA); attr(); GL.glDrawArrays(GL.GL_TRIANGLES, 0, c.nA) }
        GL.glEnable(GL.GL_BLEND); GL.glDepthMask(false); GL.glUniform1f(uA, 0f)
        for (c in list) { if (c.nW == 0) continue; GL.glBindBuffer(GL.GL_ARRAY_BUFFER, c.bW); attr(); GL.glDrawArrays(GL.GL_TRIANGLES, 0, c.nW) }
        GL.glDepthMask(true); GL.glDisable(GL.GL_BLEND); GL.glUniform1f(uA, 1f)
        // entidades
        val o = FB()
        for (m in g.mobs) drawMob(o, m)
        for (p in g.parts) Geo.box(o, p.x, p.y, p.z, .1f, .1f, .1f, p.tile, p.tile, p.tile, null, .9f)
        for (t in g.tnts) { val f = if (floor(t.t * 5).toInt() % 2 == 1) pk.tile("c:255,255,255") else pk.tile("tnt"); Geo.box(o, t.x + .5f, t.y + .5f, t.z + .5f, 1.02f, 1.02f, 1.02f, f, f, f, null, 1f) }
        dyn(o)
        // contorno del bloque apuntado
        val r = g.ray(Cfg.REACH)
        if (r != null && pk.blocks[r.id]!!.hard >= 0) {
            val l = FB(); val e = .003f; val bt = pk.tile("c:0,0,0"); val uu = ((bt and 15) + .5f) / 16f; val vv = ((bt shr 4) + .5f) / 16f
            val C = arrayOf(intArrayOf(0, 0, 0), intArrayOf(1, 0, 0), intArrayOf(1, 0, 1), intArrayOf(0, 0, 1), intArrayOf(0, 1, 0), intArrayOf(1, 1, 0), intArrayOf(1, 1, 1), intArrayOf(0, 1, 1))
            val E = intArrayOf(0, 1, 1, 2, 2, 3, 3, 0, 4, 5, 5, 6, 6, 7, 7, 4, 0, 4, 1, 5, 2, 6, 3, 7)
            for (i in E) l.v(r.x + C[i][0] * (1 + 2 * e) - e, r.y + C[i][1] * (1 + 2 * e) - e, r.z + C[i][2] * (1 + 2 * e) - e, uu, vv, 1f)
            up(lineB, l, GL.GL_DYNAMIC_DRAW); attr(); GL.glDrawArrays(GL.GL_LINES, 0, 24)
        }
        // mano
        GL.glClear(GL.GL_DEPTH_BUFFER_BIT); GL.glUniformMatrix4fv(uM, 1, false, pm, 0); GL.glUniform1f(uF, 1e6f); GL.glUniform1f(uL, 1f)
        val ho = FB(); drawHand(ho, g.held()); dyn(ho)
    }

    private fun drawMob(o: FB, m: Mob) {
        val bones = pk.models[m.type] ?: return
        val mv = hypot(m.vx, m.vz) > .2f
        val an = m.type + (if (m.fuse > 0) ".fuse" else if (mv) ".walk" else ".idle")
        val cy = cos(m.yaw); val sy = sin(m.yaw)
        for (bn in bones) {
            val rx = pk.sample(an, m.at, bn.name, "rot_x", 0f) * DEG; val ry = pk.sample(an, m.at, bn.name, "rot_y", 0f) * DEG
            val sc = pk.sample(an, m.at, bn.name, "scale", 1f)
            val cr = cos(rx); val sr = sin(rx); val cj = cos(ry); val sj = sin(ry); val pv = bn.pivot
            val tl = if (m.hurt > 0) pk.tile("c:255,60,60") else bn.tile
            for (cu in bn.cubes) {
                Geo.box(o, cu[0] + cu[3] / 2, cu[1] + cu[4] / 2, cu[2] + cu[5] / 2, cu[3], cu[4], cu[5], tl, tl, tl, { p ->
                    var x = (p[0] - pv[0]) * sc; var y = (p[1] - pv[1]) * sc; var z = (p[2] - pv[2]) * sc
                    val y1 = y * cr - z * sr; val z1 = y * sr + z * cr; y = y1; z = z1
                    val x1 = x * cj + z * sj; z = -x * sj + z * cj; x = x1
                    x = (x + pv[0]) / 16f; y = (y + pv[1]) / 16f; z = (z + pv[2]) / 16f
                    floatArrayOf(m.x + x * cy + z * sy, m.y + y, m.z - x * sy + z * cy)
                }, 0f)
            }
        }
    }

    private fun drawHand(o: FB, h: Held?) {
        val walk = hypot(g.P.vx, g.P.vz) > 1.5f && g.P.og
        val an = if (g.brk != null) "fp.hand_mine" else if (g.swingT > 0) "fp.hand_swing" else if (walk) "fp.hand_walk" else "fp.hand_idle"
        val t = if (g.swingT > 0) g.swingT else (System.nanoTime() / 1e9f)
        val px = pk.sample(an, t, "hand", "pos_x", 0f) * .03f; val py = pk.sample(an, t, "hand", "pos_y", 0f) * .03f
        val pz = pk.sample(an, t, "hand", "pos_z", 0f) * .03f; val rx = pk.sample(an, t, "hand", "rot_x", 0f) * DEG
        val c = cos(rx); val s = sin(rx); val cj = cos(-.35f); val sj = sin(-.35f)
        val xf = { p: FloatArray ->
            var x = p[0] - .5f; var y = p[1] + .55f; var z = p[2] + .9f
            val y1 = y * c - z * s; val z1 = y * s + z * c; y = y1; z = z1
            val x1 = x * cj + z * sj; z = -x * sj + z * cj; x = x1
            floatArrayOf(x + .5f + px, y - .55f + py, z - .9f + pz)
        }
        val sk = pk.tile("c:210,160,120")
        if (h == null) { Geo.box(o, .5f, -.7f, -.7f, .2f, .2f, .6f, sk, sk, sk, xf, 1f); return }
        if (h.block) {
            val b = pk.blocks[h.id]!!
            Geo.box(o, .5f, -.5f, -.9f, .4f, .4f, .4f, b.top, b.bot, b.side, xf, 1f)
        } else {
            val tl = h.item?.tile ?: 0
            Geo.box(o, .5f, -.4f, -.9f, .6f, .6f, .03f, tl, tl, tl, xf, 1f)
        }
        Geo.box(o, .62f, -.8f, -.75f, .15f, .15f, .5f, sk, sk, sk, xf, 1f)
    }
}
