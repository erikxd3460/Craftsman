package com.craftam.game

import android.content.Context
import android.graphics.*
import org.json.JSONArray
import org.json.JSONObject

class Block(val id: Int, val name: String, val top: Int, val bot: Int, val side: Int, val hard: Float, val tool: String,
            val sound: String, val trans: Boolean, val fluid: Boolean, val light: Int, val torch: Boolean)
class Item(val name: String, val tile: Int, val kind: String, val speed: Float, val damage: Float, val food: Int)
class Bone(val name: String, val pivot: FloatArray, val tile: Int, val cubes: List<FloatArray>)
class Track(val t: FloatArray, val v: FloatArray)
class Anim(val loop: Boolean, val len: Float, val tr: HashMap<String, Track>)
class Biome(val name: String, val surface: String, val sub: String, val trees: Double, val tree: String, val cactus: Double, val height: Double)
class Ore(val block: String, val y0: Int, val y1: Int, val size: Int, val tries: Int)
class Struct(val name: String, val biomes: List<String>, val chance: Double, val underground: Boolean)
/** Valores que vienen de world/world.json */
object Cfg { var SEA = 20; var G = 28f; var JUMP = 8.6f; var WALK = 4.3f; var RUN = 5.6f; var REACH = 5f; var LAVAY = 9; var RDDEF = 6 }

/** Lee la carpeta "Craftam GH" (bloques, ítems, texturas, modelos, animaciones) desde assets. */
class Pack(val ctx: Context) {
    val R = "Craftam GH"
    private val am = ctx.assets
    val tiles = HashMap<String, Int>()
    private val bmps = ArrayList<Bitmap>()
    val blocks = ArrayList<Block?>()
    val bid = HashMap<String, Int>()
    val items = LinkedHashMap<String, Item>()
    val models = HashMap<String, List<Bone>>()
    val anims = HashMap<String, Anim>()
    lateinit var atlas: Bitmap
    lateinit var menu: JSONObject
    lateinit var tactil: JSONObject
    lateinit var logo: Bitmap
    lateinit var btnTex: Bitmap
    lateinit var bgTex: Bitmap
    val biomes = HashMap<String, Biome>()
    val ores = ArrayList<Ore>()
    val structs = ArrayList<Struct>()

    private fun bmp(p: String): Bitmap = am.open(p).use { BitmapFactory.decodeStream(it) }
    private fun json(p: String) = JSONObject(am.open(p).bufferedReader().use { it.readText() })
    private fun addTile(n: String, b: Bitmap) { tiles[n] = bmps.size; bmps.add(b) }
    fun tile(n: String) = tiles[n] ?: 0
    private fun colorTile(n: String, c: Int) {
        if (tiles.containsKey(n)) return
        val b = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888); b.eraseColor(c); addTile(n, b)
    }

    fun load() {
        for (f in am.list("$R/texture/blocks")!!) addTile(f.removeSuffix(".png"), bmp("$R/texture/blocks/$f"))
        for (f in am.list("$R/texture/items")!!) addTile("i:" + f.removeSuffix(".png"), bmp("$R/texture/items/$f"))
        // modelos
        val mj = json("$R/model/models.json").getJSONObject("models")
        for (mn in mj.keys()) {
            val bl = ArrayList<Bone>(); val ba = mj.getJSONObject(mn).getJSONArray("bones")
            for (i in 0 until ba.length()) {
                val b = ba.getJSONObject(i); val c = b.getJSONArray("color")
                val r = c.getInt(0); val g = c.getInt(1); val bb = c.getInt(2)
                val tn = "c:$r,$g,$bb"; colorTile(tn, Color.rgb(r, g, bb))
                val pv = b.getJSONArray("pivot"); val cubes = ArrayList<FloatArray>()
                val ca = b.getJSONArray("cubes")
                for (k in 0 until ca.length()) {
                    val o = ca.getJSONObject(k).getJSONArray("origin"); val s = ca.getJSONObject(k).getJSONArray("size")
                    cubes.add(floatArrayOf(o.getDouble(0).toFloat(), o.getDouble(1).toFloat(), o.getDouble(2).toFloat(),
                        s.getDouble(0).toFloat(), s.getDouble(1).toFloat(), s.getDouble(2).toFloat()))
                }
                bl.add(Bone(b.getString("name"), floatArrayOf(pv.getDouble(0).toFloat(), pv.getDouble(1).toFloat(), pv.getDouble(2).toFloat()), tile(tn), cubes))
            }
            models[mn] = bl
        }
        colorTile("c:255,60,60", Color.rgb(255, 60, 60)); colorTile("c:210,160,120", Color.rgb(210, 160, 120))
        colorTile("c:255,255,255", Color.WHITE); colorTile("c:0,0,0", Color.BLACK); colorTile("c:90,90,90", Color.rgb(90, 90, 90))
        colorTile("c:sun", Color.rgb(255, 240, 150)); colorTile("c:moon", Color.rgb(230, 235, 245))
        // animaciones
        val aj = json("$R/animation-model/animations.json").getJSONObject("animations")
        for (an in aj.keys()) {
            val a = aj.getJSONObject(an); val tr = HashMap<String, Track>(); val ks = a.getJSONArray("keys")
            for (i in 0 until ks.length()) {
                val k = ks.getJSONObject(i); val kk = k.getJSONArray("keys")
                val t = FloatArray(kk.length()); val v = FloatArray(kk.length())
                for (j in 0 until kk.length()) { t[j] = kk.getJSONObject(j).getDouble("t").toFloat(); v[j] = kk.getJSONObject(j).getDouble("v").toFloat() }
                tr[k.getString("bone") + "|" + k.getString("channel")] = Track(t, v)
            }
            anims[an] = Anim(a.getBoolean("loop"), a.getDouble("length").toFloat(), tr)
        }
        // bloques
        val bj = am.list("$R/block")!!.map { json("$R/block/$it") }.sortedBy { it.getInt("id") }
        blocks.add(null)
        for (j in bj) {
            val t = j.getJSONObject("textures"); val torch = j.getString("shape") == "torch"
            val b = Block(j.getInt("id"), j.getString("name"), tile(t.getString("top")), tile(t.getString("bottom")), tile(t.getString("side")),
                j.getDouble("hardness").toFloat(), j.getString("tool"), j.getString("sound"),
                j.getBoolean("transparent") || j.getBoolean("fluid") || torch, j.getBoolean("fluid"), j.getInt("light"), torch)
            blocks.add(b); bid[b.name] = b.id
        }
        // ítems
        for (f in am.list("$R/item")!!) {
            val j = json("$R/item/$f"); val n = j.getString("name"); val last = n.substringAfterLast('_')
            val kind = if (last in listOf("pickaxe", "axe", "shovel", "sword", "hoe")) last else ""
            items[n] = Item(n, tile("i:$n"), kind, j.optDouble("speed", 1.0).toFloat(), j.optDouble("damage", 1.0).toFloat(), j.optInt("food", 0))
        }
        atlas = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        val cv = Canvas(atlas)
        for ((i, b) in bmps.withIndex()) cv.drawBitmap(b, ((i % 16) * 16).toFloat(), ((i / 16) * 16).toFloat(), null)
        loadConfig()
    }

    private fun strs(a: JSONArray?): List<String> { val l = ArrayList<String>(); if (a != null) for (i in 0 until a.length()) l.add(a.getString(i)); return l }

    /** menu/, world/ y Tactil-controles/ */
    private fun loadConfig() {
        menu = json("menu/MenGd.json"); tactil = json("Tactil-controles/tactil.json")
        logo = bmp("menu/logo/logo.png"); btnTex = bmp("menu/texture/button.png"); bgTex = bmp("menu/texture/bg.png")
        val w = json("world/world.json")
        Cfg.SEA = w.getInt("sea_level"); Cfg.G = w.getDouble("gravity").toFloat(); Cfg.JUMP = w.getDouble("jump").toFloat()
        Cfg.WALK = w.getDouble("walk").toFloat(); Cfg.RUN = w.getDouble("run").toFloat(); Cfg.REACH = w.getDouble("reach").toFloat()
        Cfg.LAVAY = w.getInt("lava_lakes_below_y"); Cfg.RDDEF = w.getInt("render_distance")
        val bi = w.getJSONArray("biomes")
        for (i in 0 until bi.length()) {
            val b = bi.getJSONObject(i)
            biomes[b.getString("name")] = Biome(b.getString("name"), b.getString("surface"), b.getString("sub"), b.optDouble("trees", 0.0),
                b.optString("tree", ""), b.optDouble("cactus", 0.0), b.optDouble("height", 1.0))
        }
        val oa = w.getJSONArray("ores")
        for (i in 0 until oa.length()) {
            val o = oa.getJSONObject(i); val y = o.getJSONArray("y")
            ores.add(Ore(o.getString("block"), y.getInt(0), y.getInt(1), o.getInt("size"), o.getInt("tries")))
        }
        val sa = json("world/structures/structures.json").getJSONArray("structures")
        for (i in 0 until sa.length()) {
            val s = sa.getJSONObject(i)
            structs.add(Struct(s.getString("name"), strs(s.optJSONArray("biome")), s.getDouble("chance"), s.optBoolean("underground", false)))
        }
    }

    fun sample(an: String, t0: Float, bone: String, ch: String, def: Float): Float {
        val a = anims[an] ?: return def
        val tr = a.tr["$bone|$ch"] ?: return def
        val t = if (a.loop) t0 % a.len else minOf(t0, a.len)
        if (t <= tr.t[0]) return tr.v[0]
        for (i in 1 until tr.t.size) if (t <= tr.t[i]) {
            val f = (t - tr.t[i - 1]) / maxOf(tr.t[i] - tr.t[i - 1], 1e-6f)
            return tr.v[i - 1] + (tr.v[i] - tr.v[i - 1]) * f
        }
        return tr.v[tr.v.size - 1]
    }
}
