package com.craftam.game

import java.io.File
import kotlin.math.*
import kotlin.random.Random

const val H = 64

class Chunk(val cx: Int, val cz: Int) {
    var d = ByteArray(16 * H * 16)
    var dirty = true
    var mod = false          // modificado por el jugador -> se guarda
    var bA = 0; var nA = 0; var bW = 0; var nW = 0
}

class World(val pk: Pack) {
    val ch = HashMap<Long, Chunk>()
    var seed = Random.nextDouble() * 1000
    var saveDir: File? = null
    private fun k(x: Int, z: Int) = (x.toLong() shl 32) xor (z.toLong() and 0xffffffffL)
    fun chunk(cx: Int, cz: Int) = ch[k(cx, cz)]
    fun put(c: Chunk) { ch[k(c.cx, c.cz)] = c }
    fun remove(c: Chunk) { ch.remove(k(c.cx, c.cz)) }
    private fun b(n: String) = pk.bid[n] ?: 0
    val stone = b("stone"); val sand = b("sand"); val water = b("water"); val lava = b("lava"); val bedrock = b("bedrock")
    val grass = b("grass"); val snow = b("snow")

    fun get(x: Int, y: Int, z: Int): Int {
        if (y < 0) return 1
        if (y >= H) return 0
        val c = ch[k(x shr 4, z shr 4)] ?: return -1
        return c.d[(y * 16 + (z and 15)) * 16 + (x and 15)].toInt() and 255
    }
    fun set(x: Int, y: Int, z: Int, id: Int) {
        val cx = x shr 4; val cz = z shr 4
        val c = ch[k(cx, cz)] ?: return
        if (y < 0 || y >= H) return
        c.d[(y * 16 + (z and 15)) * 16 + (x and 15)] = id.toByte(); c.dirty = true; c.mod = true
        val lx = x and 15; val lz = z and 15
        if (lx == 0) dirty(cx - 1, cz); if (lx == 15) dirty(cx + 1, cz)
        if (lz == 0) dirty(cx, cz - 1); if (lz == 15) dirty(cx, cz + 1)
    }
    fun dirty(cx: Int, cz: Int) { ch[k(cx, cz)]?.dirty = true }
    fun solid(i: Int) = i != 0 && (i < 0 || !(pk.blocks[i]!!.fluid || pk.blocks[i]!!.torch))
    fun topY(x: Int, z: Int): Int { for (y in H - 1 downTo 1) { val b = get(x, y, z); if (b > 0 && !pk.blocks[b]!!.torch) return y }; return 0 }

    // ---- guardado (x_z.chunk dentro de filesDir/world/Chunks)
    fun saveAll() {
        val dir = saveDir ?: return; dir.mkdirs()
        for (c in ch.values) if (c.mod) { try { File(dir, "${c.cx}_${c.cz}.chunk").writeBytes(c.d); c.mod = false } catch (e: Exception) { } }
    }
    private fun loadChunk(cx: Int, cz: Int): ByteArray? {
        val f = File(saveDir ?: return null, "${cx}_${cz}.chunk")
        return try { if (f.exists() && f.length() == (16L * H * 16)) f.readBytes() else null } catch (e: Exception) { null }
    }

    // ---- ruido
    private fun h2(x: Double, y: Double): Double { val n = sin(x * 127.1 + y * 311.7 + seed) * 43758.5453; return n - floor(n) }
    private fun h3(x: Double, y: Double, z: Double): Double { val n = sin(x * 12.9898 + y * 78.233 + z * 37.719 + seed) * 43758.5453; return n - floor(n) }
    private fun n2(x: Double, y: Double): Double {
        val xi = floor(x); val yi = floor(y); val xf = x - xi; val yf = y - yi
        val u = xf * xf * (3 - 2 * xf); val v = yf * yf * (3 - 2 * yf)
        return h2(xi, yi) * (1 - u) * (1 - v) + h2(xi + 1, yi) * u * (1 - v) + h2(xi, yi + 1) * (1 - u) * v + h2(xi + 1, yi + 1) * u * v
    }
    private fun n3(x: Double, y: Double, z: Double): Double {
        val xi = floor(x); val yi = floor(y); val zi = floor(z); val a = x - xi; val b = y - yi; val c = z - zi
        var r = 0.0
        for (i in 0..1) for (j in 0..1) for (k in 0..1)
            r += h3(xi + i, yi + j, zi + k) * (if (i == 1) a else 1 - a) * (if (j == 1) b else 1 - b) * (if (k == 1) c else 1 - c)
        return r
    }
    private fun fbm(x: Double, z: Double) = n2(x * .012, z * .012) * .55 + n2(x * .035, z * .035) * .3 + n2(x * .1, z * .1) * .15
    private fun biomeAt(x: Int, z: Int, e: Double): Biome {
        val t = n2(x * .004 + 100, z * .004 + 50); val m = n2(x * .01 + 9, z * .01)
        val n = if (t > .64) "desert" else if (t < .3) (if (m > .5) "taiga" else "snow") else if (e > .68) "hills"
        else if (m > .62) "birch_forest" else if (m > .5) "forest" else "plains"
        return pk.biomes[n] ?: pk.biomes["plains"]!!
    }

    fun gen(cx: Int, cz: Int): ByteArray {
        loadChunk(cx, cz)?.let { return it }
        val d = ByteArray(16 * H * 16)
        val hm = IntArray(256); val rnd = java.util.Random((seed * 1000).toLong() xor (cx * 341873128712L) xor (cz * 132897987541L))
        fun put(x: Int, y: Int, z: Int, i: Int) {
            if (x in 0..15 && z in 0..15 && y in 0 until H) { val p = (y * 16 + z) * 16 + x; if (d[p].toInt() == 0) d[p] = i.toByte() }
        }
        for (lz in 0..15) for (lx in 0..15) {
            val X = cx * 16 + lx; val Z = cz * 16 + lz
            val e = fbm(X.toDouble(), Z.toDouble()); val bio = biomeAt(X, Z, e)
            val h = min(H - 10, floor(14 + e * 30 * (if (e > .68) bio.height else 1.0)).toInt()); hm[lz * 16 + lx] = h
            val beach = h <= Cfg.SEA + 1 && h >= Cfg.SEA - 2 && bio.name != "snow" && bio.name != "taiga"
            val top = b(bio.surface); val sub = b(bio.sub)
            for (y in 0..h) {
                var id = stone; val dep = h - y
                if (y == 0) id = bedrock
                else if (dep == 0) id = if (beach || h < Cfg.SEA) sand else top
                else if (dep < 4) { id = if (beach) sand else sub; if (h < Cfg.SEA - 1) id = sand }
                if (y > 1 && dep > 2 && n3(X * .07, y * .1, Z * .07) > .74) id = if (y <= Cfg.LAVAY / 2) lava else 0
                if (id != 0) d[(y * 16 + lz) * 16 + lx] = id.toByte()
            }
            for (y in h + 1..Cfg.SEA) d[(y * 16 + lz) * 16 + lx] = water.toByte()
        }
        // vetas de mineral (world.json: ores)
        for (o in pk.ores) {
            val id = b(o.block); if (id == 0) continue
            repeat(o.tries) {
                var x = rnd.nextInt(16); var y = o.y0 + rnd.nextInt(max(1, o.y1 - o.y0 + 1)); var z = rnd.nextInt(16)
                repeat(o.size) {
                    if (x in 0..15 && z in 0..15 && y in 1 until H) { val p = (y * 16 + z) * 16 + x; if (d[p].toInt() == stone) d[p] = id.toByte() }
                    x += rnd.nextInt(3) - 1; y += rnd.nextInt(3) - 1; z += rnd.nextInt(3) - 1
                }
            }
        }
        // árboles, cactus
        for (lz in 3..12) for (lx in 3..12) {
            val X = cx * 16 + lx; val Z = cz * 16 + lz; val h = hm[lz * 16 + lx]; if (h <= Cfg.SEA + 1) continue
            val bio = biomeAt(X, Z, fbm(X.toDouble(), Z.toDouble())); val topId = d[(h * 16 + lz) * 16 + lx].toInt() and 255
            val r = h2(X * 3.1, Z * 7.7)
            if (bio.trees > 0 && (topId == grass || topId == snow) && r < bio.trees) {
                val kind = if (bio.tree.isEmpty()) "oak" else bio.tree
                val lg = b(kind + "_log"); val lf = b(kind + "_leaves")
                val th = (if (kind == "spruce") 5 else 4) + floor(h2(X.toDouble(), Z.toDouble()) * 2).toInt()
                for (y in h + 1..h + th) put(lx, y, lz, lg)
                for (dy in th - 2..th + 1) {
                    val rr = if (dy > th - 1) 1 else 2
                    for (a in -rr..rr) for (bb in -rr..rr) if (!(abs(a) == rr && abs(bb) == rr && dy > th - 1)) put(lx + a, h + dy, lz + bb, lf)
                }
            } else if (bio.cactus > 0 && topId == sand && r < bio.cactus) {
                for (y in 1..1 + floor(h2(Z.toDouble(), X.toDouble()) * 3).toInt()) put(lx, h + y, lz, b("cactus"))
            }
        }
        structures(d, cx, cz, hm, rnd)
        return d
    }

    // ---- estructuras (world/structures/structures.json)
    private fun structures(d: ByteArray, cx: Int, cz: Int, hm: IntArray, rnd: java.util.Random) {
        val cxw = cx * 16 + 8; val czw = cz * 16 + 8
        val bio = biomeAt(cxw, czw, fbm(cxw.toDouble(), czw.toDouble()))
        fun sb(x: Int, y: Int, z: Int, n: String) { if (x in 0..15 && z in 0..15 && y in 1 until H) d[(y * 16 + z) * 16 + x] = b(n).toByte() }
        for (s in pk.structs) {
            if (rnd.nextDouble() >= s.chance * 50) continue
            if (!s.underground && s.biomes.isNotEmpty() && bio.name !in s.biomes) continue
            val ox = 2 + rnd.nextInt(6); val oz = 2 + rnd.nextInt(6); val gy = hm[oz * 16 + ox] + 1
            if (!s.underground && gy <= Cfg.SEA + 1) continue
            when (s.name) {
                "small_house" -> {
                    for (x in 0..6) for (z in 0..6) {
                        for (y in 0..5) sb(ox + x, gy + y, oz + z, "air")
                        for (y in gy - 4 until gy - 1) if ((d[(y * 16 + oz + z) * 16 + ox + x].toInt()) == 0) sb(ox + x, y, oz + z, "cobblestone")
                        sb(ox + x, gy - 1, oz + z, "oak_planks"); sb(ox + x, gy + 3, oz + z, "cobblestone")
                        val edge = x == 0 || x == 6 || z == 0 || z == 6
                        if (edge) for (y in 0..2) sb(ox + x, gy + y, oz + z, if ((x == 0 || x == 6) && (z == 0 || z == 6)) "oak_log" else "oak_planks")
                    }
                    sb(ox + 3, gy, oz, "air"); sb(ox + 3, gy + 1, oz, "air")
                    sb(ox, gy + 1, oz + 3, "glass"); sb(ox + 6, gy + 1, oz + 3, "glass"); sb(ox + 3, gy + 1, oz + 6, "glass")
                    sb(ox + 1, gy, oz + 1, "crafting_table"); sb(ox + 5, gy, oz + 1, "chest"); sb(ox + 5, gy, oz + 5, "torch"); sb(ox + 1, gy, oz + 5, "torch")
                }
                "desert_well" -> {
                    for (x in 0..4) for (z in 0..4) { sb(ox + x, gy - 1, oz + z, "sandstone"); sb(ox + x, gy, oz + z, "air"); sb(ox + x, gy + 1, oz + z, "air") }
                    for (x in 1..3) for (z in 1..3) sb(ox + x, gy, oz + z, if (x == 2 && z == 2) "water" else "sandstone")
                    for (x in 1..3) for (z in 1..3) if (!(x == 2 && z == 2)) sb(ox + x, gy + 1, oz + z, "air")
                }
                "mine_shaft" -> {
                    val y0 = 10
                    for (x in 0..15) for (z in -1..1) for (y in 0..2) sb(x, y0 + y, oz + z, "air")
                    for (x in 0..15 step 4) { for (y in 0..1) { sb(x, y0 + y, oz - 1, "oak_planks"); sb(x, y0 + y, oz + 1, "oak_planks") }; for (z in -1..1) sb(x, y0 + 2, oz + z, "oak_planks") }
                    sb(2, y0, oz, "torch"); sb(10, y0, oz, "torch"); sb(14, y0, oz, "chest")
                }
                "pumpkin_patch" -> repeat(6) {
                    val x = ox + rnd.nextInt(5); val z = oz + rnd.nextInt(5)
                    if (x in 0..15 && z in 0..15 && (d[(hm[z * 16 + x] * 16 + z) * 16 + x].toInt() and 255) == grass) sb(x, hm[z * 16 + x] + 1, z, "pumpkin")
                }
                "ruined_tower" -> {
                    for (x in 0..4) for (z in 0..4) {
                        for (y in 0..8) sb(ox + x, gy + y, oz + z, "air")
                        sb(ox + x, gy - 1, oz + z, "stone_bricks")
                        if (x == 0 || x == 4 || z == 0 || z == 4) for (y in 0..7) if (rnd.nextInt(5) != 0 && !(x == 2 && z == 0 && y < 2)) sb(ox + x, gy + y, oz + z, "mossy_cobblestone")
                    }
                    sb(ox + 2, gy, oz + 2, "chest"); sb(ox + 1, gy, oz + 3, "torch")
                }
            }
        }
    }

    /** Devuelve (opaco, agua/transparente). */
    fun mesh(c: Chunk): Pair<FB, FB> {
        val A = FB(); val W = FB(); val x0 = c.cx * 16; val z0 = c.cz * 16
        fun gb(X: Int, y: Int, Z: Int): Int {
            val a = X - x0; val b = Z - z0
            return if (a in 0..15 && b in 0..15 && y in 0 until H) c.d[(y * 16 + b) * 16 + a].toInt() and 255 else get(X, y, Z)
        }
        for (y in 0 until H) for (lz in 0..15) for (lx in 0..15) {
            val id = c.d[(y * 16 + lz) * 16 + lx].toInt() and 255; if (id == 0) continue
            val b = pk.blocks[id] ?: continue; val X = x0 + lx; val Z = z0 + lz; val out = if (b.fluid) W else A
            val em = if (b.light >= 10) 2f else 0f
            if (b.torch) {
                Geo.quad(out, arrayOf(floatArrayOf(X.toFloat(), y.toFloat(), Z.toFloat()), floatArrayOf(X + 1f, y.toFloat(), Z + 1f), floatArrayOf(X + 1f, y + 1f, Z + 1f), floatArrayOf(X.toFloat(), y + 1f, Z.toFloat())), b.side, false, 1f + em)
                Geo.quad(out, arrayOf(floatArrayOf(X + 1f, y.toFloat(), Z.toFloat()), floatArrayOf(X.toFloat(), y.toFloat(), Z + 1f), floatArrayOf(X.toFloat(), y + 1f, Z + 1f), floatArrayOf(X + 1f, y + 1f, Z.toFloat())), b.side, false, 1f + em)
                continue
            }
            for (f in 0 until 6) {
                val dd = Geo.FD[f]; val n = gb(X + dd[0], y + dd[1], Z + dd[2])
                if (n < 0) continue
                if (n != 0) {
                    val nb = pk.blocks[n] ?: continue
                    if (!(nb.trans || nb.fluid || nb.torch)) continue
                    if (n == id && (b.fluid || b.name == "glass" || b.name == "ice")) continue
                }
                val dr = if (b.fluid && f == 0 && gb(X, y + 1, Z) != id) .88f else 1f
                val p = Array(4) { i ->
                    val q = Geo.FC[f][i]
                    floatArrayOf(X + q[0].toFloat(), y + (if (q[1] == 1) dr else 0f), Z + q[2].toFloat())
                }
                Geo.quad(out, p, if (f == 0) b.top else if (f == 1) b.bot else b.side, f < 2, Geo.FS[f] + em)
            }
        }
        return Pair(A, W)
    }
}
