package com.craftam.game

import android.content.Context
import java.io.File
import kotlin.math.*
import kotlin.random.Random

open class Body { var x = 0f; var y = 0f; var z = 0f; var vx = 0f; var vy = 0f; var vz = 0f; var w = .3f; var h = 1.8f; var og = false; var bx = false }
class Mob(val type: String) : Body() {
    var hp = 20f; var sp = 2.6f; var yaw = 0f; var t = 0f; var wx = 0f; var wz = 0f; var at = 0f; var cd = 0f; var fuse = 0f; var hurt = 0f; var hos = false
}
class Part(var x: Float, var y: Float, var z: Float, var vx: Float, var vy: Float, var vz: Float, var l: Float, val tile: Int)
class Tnt(val x: Int, val y: Int, val z: Int, var t: Float)
class Hit(val x: Int, val y: Int, val z: Int, val nx: Int, val ny: Int, val nz: Int, val id: Int, val t: Float)
class Held(val block: Boolean, val name: String, val id: Int, val item: Item?)
class Settings(ctx: Context, menu: org.json.JSONObject) {
    private val sp = ctx.getSharedPreferences("craftam", 0); private val df = menu.getJSONObject("defaults")
    var sens = sp.getFloat("sens", df.getDouble("sensitivity").toFloat())
    var rd = sp.getInt("rd", df.getInt("render_distance"))
    var music = sp.getFloat("music", df.getDouble("music").toFloat())
    var sounds = sp.getFloat("sounds", df.getDouble("sounds").toFloat())
    var btn = sp.getFloat("btn", df.getDouble("button_scale").toFloat())
    var fov = sp.getInt("fov", df.getInt("fov"))
    fun reset() {
        sens = df.getDouble("sensitivity").toFloat(); rd = df.getInt("render_distance"); music = df.getDouble("music").toFloat()
        sounds = df.getDouble("sounds").toFloat(); btn = df.getDouble("button_scale").toFloat(); fov = df.getInt("fov"); save()
    }
    fun save() { sp.edit().putFloat("sens", sens).putInt("rd", rd).putFloat("music", music).putFloat("sounds", sounds).putFloat("btn", btn).putInt("fov", fov).apply() }
}
class Brk(val x: Int, val y: Int, val z: Int, var t: Float, var need: Float)

class Game(val ctx: Context, val pk: Pack) {
    val world = World(pk)
    val sfx = Sfx(ctx, pk)
    val st = Settings(ctx, pk.menu)
    val P = Body()
    var yaw = 0f; var pitch = 0f; var hp = 20f; var fly = false; var fall = 0f
    var spx = 8f; var spy = 40f; var spz = 8f
    val hot = arrayOf("i:diamond_pickaxe", "i:diamond_sword", "b:grass", "b:dirt", "b:stone", "b:oak_planks", "b:torch", "b:glass", "i:bread")
    @Volatile var sel = 0
    // entradas (las escribe HudView)
    @Volatile var joyX = 0f; @Volatile var joyY = 0f; @Volatile var lookDX = 0f; @Volatile var lookDY = 0f
    @Volatile var brkIn = false; @Volatile var jumpIn = false; @Volatile var downIn = false; @Volatile var plcEv = false; @Volatile var flyEv = false
    var dayT = .3f; var swingT = 0f; var hurtT = 0f; var stepD = 0f; var hpReg = 0f; var rtime = 0f
    val mobs = ArrayList<Mob>(); val parts = ArrayList<Part>(); val tnts = ArrayList<Tnt>()
    var brk: Brk? = null
    @Volatile var ready = false        // hay un mundo cargado
    @Volatile var running = false      // jugando (no en menú/pausa/inventario)
    @Volatile var startReq = 0         // 1 = mundo nuevo, 2 = cargar mundo
    @Volatile var exitReq = false
    @Volatile var msg = ""
    @Volatile var sneak = false; @Volatile var sprint = false
    var onBreak: (() -> Unit)? = null
    val RD get() = st.rd
    val water = pk.bid["water"]!!; val lava = pk.bid["lava"]!!; val tntId = pk.bid["tnt"]!!; val bedrock = pk.bid["bedrock"]!!

    fun daylight() = (.5f + .7f * sin((dayT - .25f) * 6.2832f)).coerceIn(0f, 1f)
    fun held(): Held? {
        val s = hot[sel]; if (s.isEmpty()) return null; val t = s.substring(0, 1); val n = s.substring(2)
        return if (t == "b") Held(true, n, pk.bid[n] ?: 0, null) else Held(false, n, 0, pk.items[n])
    }

    private fun dir() = File(ctx.filesDir, "world/Chunks")
    private fun meta() = File(ctx.filesDir, "world/world.meta")
    fun hasSave() = meta().exists()

    fun start(load: Boolean) {
        val d = dir(); d.mkdirs(); world.saveDir = d
        if (load && !meta().exists()) { msg = "No hay mundo guardado"; return }
        world.ch.clear(); mobs.clear(); parts.clear(); tnts.clear(); brk = null
        var px = 0f; var py = 0f; var pz = 0f; var have = false
        if (load) {
            try {
                val l = meta().readLines(); world.seed = l[0].toDouble(); px = l[1].toFloat(); py = l[2].toFloat(); pz = l[3].toFloat()
                yaw = l[4].toFloat(); pitch = l[5].toFloat(); dayT = l[6].toFloat(); hp = l[7].toFloat()
                if (l.size > 8) { val h = l[8].split(","); for (i in 0 until min(9, h.size)) hot[i] = h[i] }
                have = true
            } catch (e: Exception) { }
        } else {
            d.listFiles()?.forEach { it.delete() }; meta().delete(); world.seed = Random.nextDouble() * 1000
            hp = 20f; dayT = .3f; yaw = 0f; pitch = 0f
        }
        val cxp = if (have) floor(px).toInt() shr 4 else 0; val czp = if (have) floor(pz).toInt() shr 4 else 0
        for (a in -2..2) for (b in -2..2) world.put(Chunk(cxp + a, czp + b).also { it.d = world.gen(cxp + a, czp + b) })
        if (have) { P.x = px; P.y = py; P.z = pz; spx = px; spy = py + 1; spz = pz }
        else {
            var f: IntArray? = null; var r = 0
            while (r < 40 && f == null) {
                var a = -r
                while (a <= r && f == null) {
                    var b = -r
                    while (b <= r && f == null) {
                        val x = 8 + a; val z = 8 + b
                        if (world.get(x, 1, z) >= 0) { val y = world.topY(x, z); if (y > Cfg.SEA + 1 && world.get(x, y, z) != water) f = intArrayOf(x, y, z) }
                        b += 2
                    }
                    a += 2
                }
                r += 2
            }
            val s = f ?: intArrayOf(8, world.topY(8, 8), 8)
            P.x = s[0] + .5f; P.y = s[1] + 1.2f; P.z = s[2] + .5f; spx = P.x; spy = P.y; spz = P.z
        }
        P.vx = 0f; P.vy = 0f; P.vz = 0f
        ready = true; running = true; msg = ""; sfx.startMusic()
    }

    fun save() {
        if (!ready) return
        try {
            world.saveAll(); meta().parentFile?.mkdirs()
            meta().writeText(listOf(world.seed, P.x, P.y, P.z, yaw, pitch, dayT, hp, hot.joinToString(",")).joinToString("\n"))
        } catch (e: Exception) { }
    }

    fun hit(x: Float, y: Float, z: Float, w: Float, h: Float): Boolean {
        for (a in floor(x - w).toInt()..floor(x + w).toInt()) for (b in floor(y).toInt()..floor(y + h - .001f).toInt())
            for (c in floor(z - w).toInt()..floor(z + w).toInt()) if (world.solid(world.get(a, b, c))) return true
        return false
    }
    fun move(e: Body, dt: Float) {
        e.og = false; e.bx = false
        var n = e.x + e.vx * dt
        if (hit(n, e.y, e.z, e.w, e.h)) { e.vx = 0f; e.bx = true } else e.x = n
        n = e.z + e.vz * dt
        if (hit(e.x, e.y, n, e.w, e.h)) { e.vz = 0f; e.bx = true } else e.z = n
        n = e.y + e.vy * dt
        if (hit(e.x, n, e.z, e.w, e.h)) { if (e.vy < 0) e.og = true; e.vy = 0f } else e.y = n
    }

    fun hurtP(d: Int, fx: Float = Float.NaN, fz: Float = 0f) {
        hp -= d; hurtT = .4f; sfx.play("hurt")
        if (!fx.isNaN()) { val l = hypot(fx, fz).coerceAtLeast(.001f); P.vx += fx / l * 4; P.vz += fz / l * 4; P.vy = 4f }
        if (hp <= 0) { sfx.play("death"); hp = 20f; P.x = spx; P.y = spy; P.z = spz; P.vx = 0f; P.vy = 0f; P.vz = 0f }
    }

    fun ray(maxD: Float): Hit? {
        val o = floatArrayOf(P.x, P.y + 1.62f, P.z); val cp = cos(pitch)
        val d = floatArrayOf(-sin(yaw) * cp, sin(pitch), -cos(yaw) * cp)
        val pos = intArrayOf(floor(o[0]).toInt(), floor(o[1]).toInt(), floor(o[2]).toInt())
        val st = IntArray(3) { if (d[it] > 0) 1 else -1 }
        val td = FloatArray(3) { abs(1f / (if (d[it] == 0f) 1e-9f else d[it])) }
        val tm = FloatArray(3) { (if (d[it] > 0) pos[it] + 1 - o[it] else o[it] - pos[it]) * td[it] }
        var n = IntArray(3); var t = 0f
        while (t < maxD) {
            val b = world.get(pos[0], pos[1], pos[2])
            if (b > 0 && !pk.blocks[b]!!.fluid) return Hit(pos[0], pos[1], pos[2], n[0], n[1], n[2], b, t)
            val i = if (tm[0] < tm[1]) { if (tm[0] < tm[2]) 0 else 2 } else { if (tm[1] < tm[2]) 1 else 2 }
            t = tm[i]; tm[i] += td[i]; pos[i] += st[i]; n = IntArray(3); n[i] = -st[i]
        }
        return null
    }

    fun burst(x: Float, y: Float, z: Float, tile: Int, n: Int) {
        repeat(n) { parts.add(Part(x, y, z, (Random.nextFloat() - .5f) * 4, Random.nextFloat() * 4, (Random.nextFloat() - .5f) * 4, .8f, tile)) }
    }
    fun explode(x: Float, y: Float, z: Float, r: Int) {
        sfx.play("explode", 1f, 1f, x, y, z)
        for (a in -r..r) for (b in -r..r) for (c in -r..r) if (a * a + b * b + c * c <= r * r) {
            val X = floor(x).toInt() + a; val Y = floor(y).toInt() + b; val Z = floor(z).toInt() + c; val i = world.get(X, Y, Z)
            if (i > 0 && pk.blocks[i]!!.hard >= 0 && i != bedrock && Y > 0) {
                if (Random.nextFloat() < .1f) burst(X + .5f, Y + .5f, Z + .5f, pk.blocks[i]!!.side, 1)
                world.set(X, Y, Z, 0)
            }
        }
        val gr = pk.tile("c:90,90,90")
        repeat(30) { parts.add(Part(x, y, z, (Random.nextFloat() - .5f) * 8, Random.nextFloat() * 6, (Random.nextFloat() - .5f) * 8, 1f, gr)) }
        val d = sqrt((P.x - x).pow(2) + (P.y - y).pow(2) + (P.z - z).pow(2))
        if (d < r * 2) hurtP(ceil((r * 2 - d) * 2.5f).toInt(), P.x - x, P.z - z)
        for (m in mobs) if (sqrt((m.x - x).pow(2) + (m.y - y).pow(2) + (m.z - z).pow(2)) < r * 2) m.hp -= 12f
    }

    // ---- mobs
    val MD = mapOf("cow" to floatArrayOf(.45f, 1.3f, 10f, 1.6f), "pig" to floatArrayOf(.4f, .9f, 10f, 1.8f), "sheep" to floatArrayOf(.4f, 1.2f, 8f, 1.7f),
        "chicken" to floatArrayOf(.2f, .6f, 4f, 1.8f), "zombie" to floatArrayOf(.3f, 1.8f, 20f, 2.6f), "creeper" to floatArrayOf(.3f, 1.7f, 20f, 2.6f))
    fun spawn(t: String) {
        val a = Random.nextFloat() * 6.28f; val r = 18 + Random.nextFloat() * 16
        val x = floor(P.x + cos(a) * r).toInt(); val z = floor(P.z + sin(a) * r).toInt()
        if (world.get(x, 1, z) < 0) return
        val y = world.topY(x, z); val b = world.get(x, y, z)
        if (b == water || b == lava || y < Cfg.SEA) return
        val m = Mob(t); val md = MD[t]!!
        m.x = x + .5f; m.y = y + 1f; m.z = z + .5f; m.w = md[0]; m.h = md[1]; m.hp = md[2]; m.sp = md[3]; m.yaw = Random.nextFloat() * 6.28f
        m.hos = t == "zombie" || t == "creeper"; mobs.add(m)
    }
    fun updMobs(dt: Float) {
        rtime -= dt
        if (rtime <= 0) {
            rtime = 2f; val day = daylight(); val an = mobs.count { !it.hos }; val ho = mobs.size - an
            if (day > .5f && an < 8) spawn(listOf("cow", "pig", "sheep", "chicken").random())
            if (day < .4f && ho < 6) spawn(if (Random.nextFloat() < .6f) "zombie" else "creeper")
        }
        var i = mobs.size - 1
        while (i >= 0) {
            val m = mobs[i]; val dx = P.x - m.x; val dz = P.z - m.z; val d = hypot(dx, dz)
            if (m.hp <= 0 || d > 70 || (m.type == "zombie" && daylight() > .7f && d > 30)) {
                if (m.hp <= 0) {
                    sfx.play(if (m.type == "zombie") "zombie_death" else if (m.type == "creeper") "creeper_death" else "pig_death", 1f, 1f, m.x, m.y, m.z)
                    burst(m.x, m.y + .5f, m.z, pk.tile("c:255,60,60"), 8)
                }
                mobs.removeAt(i); i--; continue
            }
            m.t -= dt; m.cd -= dt; m.hurt -= dt
            var tx = 0f; var tz = 0f; var mv = false
            if (m.hos && d < 18) {
                val l = max(d, .001f); tx = dx / l * m.sp; tz = dz / l * m.sp; mv = d > 1; m.yaw = atan2(-dx, -dz)
                if (m.type == "zombie" && d < 1.4f && abs(P.y - m.y) < 1.5f && m.cd <= 0) { m.cd = 1f; hurtP(3, dx, dz) }
                if (m.type == "creeper") {
                    if (d < 3) { m.fuse += dt; if (m.fuse > 1.5f) { explode(m.x, m.y + .5f, m.z, 3); m.hp = 0f; i--; continue } } else m.fuse = max(0f, m.fuse - dt)
                    if (d < 2.5f) { tx = 0f; tz = 0f; mv = false }
                }
            } else {
                if (m.t <= 0) {
                    m.t = 2 + Random.nextFloat() * 4; val a = Random.nextFloat() * 6.28f; val go = Random.nextFloat() < .6f
                    m.wx = if (go) cos(a) * m.sp * .5f else 0f; m.wz = if (go) sin(a) * m.sp * .5f else 0f
                    if (go) m.yaw = atan2(-m.wx, -m.wz)
                    if (!m.hos && Random.nextFloat() < .2f) {
                        val s = when (m.type) { "cow" -> "cow_moo"; "pig" -> "pig_oink"; "sheep" -> "sheep_baa"; else -> "chicken_cluck" }
                        sfx.play(s + (1 + Random.nextInt(3)), .8f, 1f, m.x, m.y, m.z)
                    }
                }
                tx = m.wx; tz = m.wz; mv = tx != 0f || tz != 0f
            }
            m.vx += (tx - m.vx) * min(1f, dt * 8); m.vz += (tz - m.vz) * min(1f, dt * 8); m.vy = max(m.vy - Cfg.G * dt, -30f)
            if (world.get(floor(m.x).toInt(), floor(m.y).toInt(), floor(m.z).toInt()) == water) m.vy = max(m.vy, 1.5f)
            move(m, dt); if (m.bx && m.og && mv) m.vy = 7.5f
            m.at += dt * (if (mv) 1f else .4f)
            i--
        }
    }

    // ---- acciones
    private fun sfxBlock(kind: String, id: Int, x: Float, y: Float, z: Float) {
        val so = pk.blocks[id]!!.sound
        if (kind == "dig" && so == "splash") { sfx.play("splash", 1f, 1f, x, y, z); return }
        val m = if (so == "splash") "gravel" else so
        sfx.play(kind + "_" + m + (1 + Random.nextInt(3)), 1f, 0f, x, y, z)
    }
    private fun breakStep(dt: Float, h: Held?) {
        val r = ray(Cfg.REACH)
        if (r == null || pk.blocks[r.id]!!.hard < 0) { brk = null; return }
        var b = brk
        if (b == null || b.x != r.x || b.y != r.y || b.z != r.z) { b = Brk(r.x, r.y, r.z, 0f, 0f); brk = b }
        val bl = pk.blocks[r.id]!!; val k = bl.tool.substringBefore('_')
        var spd = 1f; val it = h?.item
        if (it != null && it.kind == k) spd = it.speed
        b.need = max(.12f, bl.hard * 1.5f / (if (spd > 1f) spd * .6f else 1f)); b.t += dt
        if (Random.nextFloat() < dt * 6) sfxBlock("step", r.id, b.x.toFloat(), b.y.toFloat(), b.z.toFloat())
        if (b.t >= b.need) {
            sfxBlock("dig", r.id, b.x.toFloat(), b.y.toFloat(), b.z.toFloat()); burst(b.x + .5f, b.y + .5f, b.z + .5f, bl.side, 10)
            world.set(b.x, b.y, b.z, 0); brk = null; onBreak?.invoke()
        }
    }
    private fun attack(h: Held?): Boolean {
        val cp = cos(pitch); val d = floatArrayOf(-sin(yaw) * cp, sin(pitch), -cos(yaw) * cp); val o = floatArrayOf(P.x, P.y + 1.62f, P.z)
        val rr = ray(4f); var bt = rr?.t ?: 4f; var best: Mob? = null
        for (m in mobs) {
            val c = floatArrayOf(m.x - o[0], m.y + m.h / 2 - o[1], m.z - o[2]); val t = c[0] * d[0] + c[1] * d[1] + c[2] * d[2]
            if (t < 0 || t > bt) continue
            val q = sqrt((c[0] - d[0] * t).pow(2) + (c[1] - d[1] * t).pow(2) + (c[2] - d[2] * t).pow(2))
            if (q < max(m.w, m.h / 2) + .15f) { best = m; bt = t }
        }
        val m = best ?: return false
        m.hp -= h?.item?.let { if (it.kind.isNotEmpty()) it.damage else 1f } ?: 1f; m.hurt = .3f
        m.vx += d[0] * 6; m.vz += d[2] * 6; m.vy = 4f
        sfx.play("hit", 1f, 1f, m.x, m.y, m.z)
        if (m.type == "zombie") sfx.play("zombie_hurt", .8f, 1f, m.x, m.y, m.z) else if (m.type == "cow") sfx.play("cow_hurt", .8f, 1f, m.x, m.y, m.z)
        if (!m.hos) { m.t = 2f; m.wx = d[0] * m.sp * 1.5f; m.wz = d[2] * m.sp * 1.5f }
        return true
    }
    private fun placeStep(h: Held?) {
        swingT = .001f
        val it = h?.item
        if (it != null && it.food > 0) { if (hp < 20) { hp = min(20f, hp + it.food); sfx.play("eat") }; return }
        val r = ray(Cfg.REACH) ?: return
        if (r.id == tntId) { tnts.add(Tnt(r.x, r.y, r.z, 3f)); world.set(r.x, r.y, r.z, 0); sfx.play("fuse"); return }
        if (h == null || !h.block) return
        val x = r.x + r.nx; val y = r.y + r.ny; val z = r.z + r.nz; val cur = world.get(x, y, z)
        if (cur > 0 && !pk.blocks[cur]!!.fluid) return
        if (world.solid(h.id) && x + 1 > P.x - P.w && x < P.x + P.w && z + 1 > P.z - P.w && z < P.z + P.w && y + 1 > P.y && y < P.y + P.h) return
        world.set(x, y, z, h.id); sfx.play("place" + (1 + Random.nextInt(3)), 1f, 1f, x.toFloat(), y.toFloat(), z.toFloat())
    }

    fun update(dt: Float) {
        if (!ready || !running) return
        dayT = (dayT + dt / 480f) % 1f; sfx.night = dayT > .55f
        sfx.lx = P.x; sfx.ly = P.y; sfx.lz = P.z
        yaw -= lookDX * .012f * st.sens; pitch = (pitch - lookDY * .012f * st.sens).coerceIn(-1.5f, 1.5f); lookDX = 0f; lookDY = 0f
        if (flyEv) { flyEv = false; fly = !fly; P.vy = 0f }
        val h = held()
        var mx = joyX; var mz = joyY; val l = hypot(mx, mz); if (l > 1) { mx /= l; mz /= l }
        val run = sprint || l > .95f; var spd = if (fly) 10f else if (run) Cfg.RUN else Cfg.WALK; if (sneak && !fly) spd *= .45f
        val cy = cos(yaw); val sy = sin(yaw)
        val wx = (mx * cy + mz * sy) * spd; val wz = (-mx * sy + mz * cy) * spd
        val inW = world.get(floor(P.x).toInt(), floor(P.y + .5f).toInt(), floor(P.z).toInt()) == water
        val inL = world.get(floor(P.x).toInt(), floor(P.y + .3f).toInt(), floor(P.z).toInt()) == lava
        val k = min(1f, dt * (if (P.og || fly) 12f else 3f)); P.vx += (wx - P.vx) * k; P.vz += (wz - P.vz) * k
        if (fly) P.vy = (if (jumpIn) 7f else 0f) - (if (downIn || sneak) 7f else 0f)
        else if (inW || inL) { P.vy += (if (jumpIn) 20f else -9f) * dt; P.vy = P.vy.coerceIn(-3f, 3f) }
        else { P.vy = max(P.vy - Cfg.G * dt, -40f); if (jumpIn && P.og) P.vy = Cfg.JUMP }
        val vy0 = P.vy; move(P, dt)
        if (!P.og && P.vy < -.1f && !inW) fall += max(0f, -vy0 * dt)
        if (P.og) { if (fall > 3.2f && !fly) { hurtP(ceil(fall - 3).toInt()); sfx.play("fall_big") }; fall = 0f }
        if (inW) fall = 0f
        if (inL) { hpReg = 0f; hp -= 4 * dt; if (hp <= 0) hurtP(0) }
        if (P.og && hypot(P.vx, P.vz) > 1.5f) {
            stepD += hypot(P.vx, P.vz) * dt
            if (stepD > 2.2f) { stepD = 0f; val b = world.get(floor(P.x).toInt(), floor(P.y - .2f).toInt(), floor(P.z).toInt()); if (b > 0) sfxBlock("step", b, P.x, P.y, P.z) }
        }
        hpReg += dt; if (hpReg > 5 && hp < 20) { hp++; hpReg = 0f }
        hurtT -= dt; if (swingT > 0) { swingT += dt; if (swingT > .3f) swingT = 0f }
        if (brkIn) {
            val hitM = if (swingT == 0f) attack(h) else false
            if (hitM) { swingT = .001f; brk = null } else breakStep(dt, h)
            if (swingT == 0f && brk == null) swingT = .001f
        } else brk = null
        if (plcEv) { plcEv = false; placeStep(h) }
        updMobs(dt)
        var i = tnts.size - 1
        while (i >= 0) { val t = tnts[i]; t.t -= dt; if (t.t <= 0) { explode(t.x + .5f, t.y + .5f, t.z + .5f, 4); tnts.removeAt(i) }; i-- }
        i = parts.size - 1
        while (i >= 0) { val p = parts[i]; p.l -= dt; p.vy -= 14 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; if (p.l <= 0) parts.removeAt(i); i-- }
        // chunks
        val pcx = floor(P.x).toInt() shr 4; val pcz = floor(P.z).toInt() shr 4
        var bestD = Int.MAX_VALUE; var bx = 0; var bz = 0
        for (a in -RD - 1..RD + 1) for (b in -RD - 1..RD + 1) if (world.chunk(pcx + a, pcz + b) == null) { val d = a * a + b * b; if (d < bestD) { bestD = d; bx = pcx + a; bz = pcz + b } }
        if (bestD != Int.MAX_VALUE) {
            world.put(Chunk(bx, bz).also { it.d = world.gen(bx, bz) })
            world.dirty(bx + 1, bz); world.dirty(bx - 1, bz); world.dirty(bx, bz + 1); world.dirty(bx, bz - 1)
        }
    }
}
