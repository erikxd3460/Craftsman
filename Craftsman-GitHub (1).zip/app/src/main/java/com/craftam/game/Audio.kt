package com.craftam.game

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Handler
import android.os.Looper
import kotlin.math.hypot
import kotlin.random.Random

class Sfx(val ctx: Context, val pk: Pack) {
    private val sp = SoundPool.Builder().setMaxStreams(14).setAudioAttributes(
        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
    private val ids = HashMap<String, Int>()
    private val ready = HashSet<Int>()
    var lx = 0f; var ly = 0f; var lz = 0f
    private var mp: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    var night = false
    var sfxVol = 1f; var musicVol = .5f
    private var menuOn = false

    init {
        sp.setOnLoadCompleteListener { _, id, st -> if (st == 0) synchronized(ready) { ready.add(id) } }
        for (d in listOf("sound", "mob")) {
            for (f in ctx.assets.list("${pk.R}/saund/$d")!!) if (f.endsWith(".wav")) try {
                ctx.assets.openFd("${pk.R}/saund/$d/$f").use { ids[f.removeSuffix(".wav")] = sp.load(it, 1) }
            } catch (e: Exception) { }
        }
    }

    /** Si pasas x,y,z el volumen baja con la distancia. rate=0 -> tono aleatorio. */
    fun play(n: String, v: Float = 1f, rate: Float = 0f, x: Float = Float.NaN, y: Float = 0f, z: Float = 0f) {
        val id = ids[n] ?: return
        if (synchronized(ready) { !ready.contains(id) }) return
        var g = v * sfxVol
        if (!x.isNaN()) { g *= maxOf(0f, 1f - hypot(hypot(x - lx, y - ly), z - lz) / 24f); if (g < .02f) return }
        sp.play(id, g, g, 1, 0, if (rate > 0f) rate else .9f + Random.nextFloat() * .2f)
    }

    fun startMusic() { menuOn = false; mp?.release(); mp = null; handler.removeCallbacksAndMessages(null); handler.postDelayed({ nextTrack() }, 3000) }
    fun menuMusic(on: Boolean) {
        if (on == menuOn) return
        menuOn = on; handler.removeCallbacksAndMessages(null); mp?.release(); mp = null
        if (!on) return
        try {
            val afd = ctx.assets.openFd("menu/saund/menu_theme.wav")
            mp = MediaPlayer().apply { setDataSource(afd.fileDescriptor, afd.startOffset, afd.length); afd.close(); isLooping = true; setVolume(.4f * musicVol, .4f * musicVol); prepare(); start() }
        } catch (e: Exception) { }
    }
    fun applyVol() { try { mp?.setVolume(.3f * musicVol, .3f * musicVol) } catch (e: Exception) { } }
    private fun nextTrack() {
        try {
            val n = if (night) "night1" else listOf("calm1", "calm2").random()
            val afd = ctx.assets.openFd("${pk.R}/saund/music/$n.wav")
            mp?.release()
            mp = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length); afd.close()
                setVolume(.3f * musicVol, .3f * musicVol)
                setOnCompletionListener { handler.postDelayed({ nextTrack() }, 20000L + Random.nextLong(40000L)) }
                prepare(); start()
            }
        } catch (e: Exception) { }
    }
    fun release() { handler.removeCallbacksAndMessages(null); mp?.release(); sp.release() }
}
